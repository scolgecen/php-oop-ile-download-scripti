<?php echo $auth_message ?>
